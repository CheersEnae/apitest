import allure
import pytest

# #单参数单次循环
# @pytest.mark.parametrize("name",["阿狸"])
# def test_parametrize_01(name):
#     print("我是"+name)

#单参数多次循环
#运行时，数组里的值分别赋值给变量，有多少条数据就执行多少次

@pytest.mark.parametrize("name",["阿狸","腕豪"])
def test_parametrize_01(name):
    assert name == "阿狸"