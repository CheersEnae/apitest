import pytest


#数组的形式
@pytest.mark.parametrize("name,word",[["阿狸","爱你哦"],["腕豪","我很强"]])
def test_parametrize(name,word):
    print(name+"的台词："+word)

