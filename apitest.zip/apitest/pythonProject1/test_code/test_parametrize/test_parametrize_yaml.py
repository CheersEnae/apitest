import allure
import pytest
import requests
from test_code.test_parametrize.read_data import read_data




@allure.feature("智能质检系统")
@pytest.mark.parametrize("shouji,appkey", read_data()['mobile_params'])
def test_mobile(shouji, appkey):
    print(f"{shouji}和{appkey}")

    requests.get("http://www.baidu.com")
    assert shouji == 17677316721
    assert appkey == "04646da4d64ad6"
