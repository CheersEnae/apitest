import yaml




def read_data():
    f = open("../config/data.yaml",encoding="utf-8")
    data = yaml.safe_load(f)
    print(data['mobile_params'])
    return data

if __name__ == '__main__':
    read_data()