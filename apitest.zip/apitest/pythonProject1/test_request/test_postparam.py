import requests

params ={

}

r = requests.post("http://127.0.0.1:",params=params)
print(r.status_code)
print(r.json())