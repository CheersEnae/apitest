import  requests
params = {
    'username': 'admin',
    'password': '123456'
}
r = requests.get(url='http://httpbin.org',params=params)
