import requests

r = requests.post('https://binstd.apistd.com/weather/query?city=%E4%B8%9C%E8%8E%9E&key=4j1D7Jsu2JRXMfNf4qjWTBnP3')
# print(r.json())
# print(r.status_code)
print(r.text)