def test_two():
    assert 1==1
    assert 1!=2
    assert 2>1
    assert 1<2
    assert 1>=1
    assert 1<=1


    