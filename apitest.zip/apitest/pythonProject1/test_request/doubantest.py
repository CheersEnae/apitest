import requests

url="http://movie.douban.com/j/search_subjects"
params = {
    "type":"movie",
    "tag":"热门",
    "page_limit":20,
    "page_start":0
}
header = {
    "User-Agent":"Mozilla/5.0 (Windows NT",
}
r= requests.post(url,params=params,headers=header)

