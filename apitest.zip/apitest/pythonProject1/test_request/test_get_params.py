import requests

def test_mobile():
    r = requests.get('https://binstd.apistd.com/recipe/search?keyword=%E5%A8%83%E5%A8%83%E8%8F%9C&num=10&key=4j1D7Jsu2JRXMfNf4qjWTBnP3')
    print(r.status_code)
    print(r.text)
    assert r.status_code == 200
    result = r.json()
    assert result['status'] == 0
    assert result['msg'] == 'ok'
