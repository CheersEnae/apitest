import pytest
#
# def setup_module():
#     print("111")
#
# def teardown_module():
#     print("222")

# def setup_function():
#     print('111')
#
# def teardown_function():
#     print("222")



def test_one():
    expect = 1
    actual = 2
    assert expect == actual

def test_one2():
    expect = 1
    actual = 1
    assert expect == actual

if __name__ == '__main__':
    pytest.main()