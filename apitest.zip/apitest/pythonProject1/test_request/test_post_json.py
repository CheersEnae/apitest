import requests
json_data:{
    "title":"fff",
    "body":"hello world",
    "userId":1
}

r = requests.post("http://127.0.0.1:",json=json_data)


data:{
    "text":"hello world"
}
re = requests.post("http://127.0.0.1:",data=data)
print(re.status_code)
print(re.json())