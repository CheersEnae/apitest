import pytest

@pytest.fixture()
def func():
    print("我是前置")

def test_one(func):
    expect = 1
    actual = 2
    assert expect == actual

def test_one2():
    expect = 1
    actual = 1
    assert expect == actual

if __name__ == '__main__':
    pytest.main()